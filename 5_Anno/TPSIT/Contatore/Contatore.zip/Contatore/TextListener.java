public interface TextListener {
    public void testoEmesso(String testo);
}
