# Esercizio Contatore - Formosi Sara, Gabriele Di Coste, Francesco Suma

Per eseguire il file recarsi nel file 'Server.java' ed esegurlo. Successivamente recarsi nel file 'Main.java' ed eseguire quest'ultimo.
I dati inviati al server verrano visualizzati nella riga di comando dove è stato eseguito il server.

Nel file 'Main.java' troviamo perlappunto il main che creerà un oggetto della classe Frame, classe che si trova nel file 'Frame.java'. In quest'ultimo file viene gestita la creazione e la visualizzazione dell'interfaccia grafica. Inoltre crea un oggetto di tipo Client e richiama i metodi 'connetti' e 'comunica' che si occupano rispettivamente di stabilire una connessione con il server e di inviare dati a quest'ultimo.
