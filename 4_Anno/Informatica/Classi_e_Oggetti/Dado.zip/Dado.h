#ifndef __DADO_H__
#define __DADO_H__

class Dado{
    
    private: 
        int nFacce;
        int lastNumber;
        static int count;

    public:
        Dado(int facce);
        ~Dado();

        int lancia();
        static int getCount();
};

#endif 
