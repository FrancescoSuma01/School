#include "Dado.h"
#include <iostream>
#include <ctime>

int Dado::count = 0; //static attribute


Dado::Dado(int facce): nFacce(facce), lastNumber(0){
    count++;
    std::cout<<"Costruttore di default: "<<nFacce<<std::endl;    
}


Dado::~Dado(){
    count--;
    std::cout<<"Distruttore dado: "<<nFacce<<std::endl;   
    std::cout<<"Dadi ancora in gioco: "<<Dado::getCount()<<std::endl;   
}


int Dado::lancia(){
    //std::cout<<"Metodo lancia() ("<<nFacce<<")"<<std::endl;    
    if (!lastNumber){
        srand(time(NULL));
    }
    lastNumber = rand()%nFacce+1;
    return lastNumber;
}


int Dado::getCount(){
    return count;
}
