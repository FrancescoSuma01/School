/**
 * @file app.cpp
 * @author your name (you@domain.com)
 * @brief 
 * @version 0.1
 * @date 2022-02-21
 * 
 * @copyright Copyright (c) 2022
 * 
 * 
 * g++ -o Dado app.cpp Dado.cpp -Wall -std=c++11 -I.
 */

#include "Dado.h"
#include <iostream>

void welcomeMsg(){
    std::cout<<"Sfida ai dadi"<<std::endl;
    std::cout<<"Lancia il dado e sfida il computer! hai 10 lanci"<<std::endl;
}



int main(){

    welcomeMsg();

    Dado d1(6);

    std::cout<<"dadi in gioco: "<<d1.getCount()<<std::endl;

    Dado d2(6);
    std::cout<<"dadi in gioco: "<<Dado::getCount()<<std::endl;



    // for(int i =0; i <6; i++)
    // {
    //     std::cout<<"d1:"<<d1.lancia();//<<std::endl;
    //     std::cout<<"\t d2:"<<d2.lancia()<<std::endl;
    // }


    int nlanci = 10;
    int r1 = d1.lancia();
    int r2 = d2.lancia();

    std::cout<<"\td1 \t d2"<<std::endl;
    do
    {
        r1 = d1.lancia();
        r2 = d2.lancia();
        std::cout<<"\t"<<r1<<" \t "<<r2<<std::endl;

        nlanci--;
    } while (r1!=r2 && nlanci);
    
    // while (r1!=r2 && nlanci)
    // {
    //     std::cout<<"d1:"<<r1;
    //     std::cout<<"d2:"<<r2<<std::endl;

    //     r1 = d1.lancia();
    //     r2 = d2.lancia();

    //     nlanci--;
    // }//wend

    if (!nlanci)
    {
        std::cout<<"you loose!!"<<std::endl;
    }
    else
    {
        std::cout<<"you win at "<<10-nlanci<<" toss(es)"<<std::endl;
    }

    std::cout<<"\nBye\n"<<std::endl;
    return 0;
}

