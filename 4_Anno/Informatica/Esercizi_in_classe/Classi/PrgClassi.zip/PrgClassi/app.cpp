#include "Frazione.h"

int main() {
	
	{
		Frazione left(2,3);
		Frazione right(3,2);
		
		//Frazione s = left.operator+(right);
		
		Frazione s = left + right;
		
		left.print();
		std::cout<<" + "<<std::endl;
		right.print();
		std::cout<<" = "<<std::endl;
		
		s.print();	
	}
	
	
	
	return 0;
}
